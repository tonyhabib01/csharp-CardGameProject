﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Odd_and_Even_Card_Game
{
    public class Player
    {
        public string Name { get; set; }
        public int Score { get; set; }
        public string PlayerType { get; set; }

    }
}
